answer = input("Whats your name? ")
print("hello , " + answer)
