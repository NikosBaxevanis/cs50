x = int(input("x: "))
y = int(input("y: "))
print(x / y)