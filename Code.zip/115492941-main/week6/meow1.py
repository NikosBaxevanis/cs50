def main():
    for i in range(3):
        meow()

def meow():
    print("meow")

main()