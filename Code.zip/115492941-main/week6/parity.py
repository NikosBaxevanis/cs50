from cs50 import get_int

n = get_int("n: ")

if n % 2 == 0:
    print("Even")
else:
    print("odd")