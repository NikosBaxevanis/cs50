from cs50 import get_string

before = get_string("Before: ")
print(f"After: {before.upper()}")