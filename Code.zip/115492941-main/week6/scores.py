scores = [72 , 73 ,33]

average = sum(scores) / len(scores)
print(f"average:  {average}")