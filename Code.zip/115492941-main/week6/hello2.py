from cs50 import get_string

answer = get_string("Whats your name? ")
print(f"hello,{answer}")