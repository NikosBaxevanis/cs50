for i in range(3):
    for j in range(3):
        print("#" , end="")
    print()

# or for i in range(3):
# print("#" *3)