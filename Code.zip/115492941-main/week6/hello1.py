from cs50 import get_string

answer = get_string("whats your name? ")
print("hello , " + answer)